object Test extends App {
	println("LUL")
}